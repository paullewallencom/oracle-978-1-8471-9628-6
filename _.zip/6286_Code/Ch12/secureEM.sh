emctl secure dbconsole <sysman password> <registration password> 

emctl stop dbconsole db

emctl start dbconsole db