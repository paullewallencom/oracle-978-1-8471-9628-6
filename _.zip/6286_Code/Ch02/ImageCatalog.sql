create table image_catalog (
   image_id        number(4),
   image_description       clob,
   image   blob
);
