Rem#######################################################################################################
Rem
Rem
Rem        Copyright (c) 2002 Oracle Corporation. All rights reserved.
Rem
Rem        Data Mining Migration Utility
Rem
Rem        File Name: dmmig1.sql
Rem
Rem        xbarr      -  02/11/02    Fix bug 2221210
Rem        xbarr      -  02/01/02    Rebuild FK for ODM_CLASSIFICATION_TEST_RESULT	
Rem        xbarr      -  12/06/01    Added COUNT column for rules tables
Rem                   -  12/03/01    Modified to be called by ODMA
Rem                   -  10/10/01    Creation
Rem 
Rem        This script migrates Oracle Data Mining Product from 9.0.1 to 9.2.0
Rem
Rem        Script should be run as SYS
Rem
Rem        IMPORTANT: Prior to run this script, ODM schema should be fully exported
Rem
Rem        Note:
Rem
Rem        After applied changes to ODM schema, the serirized objects in the schema objects
Rem        such as ODM_MINING_FUNCTION_SETTING, ODM_MINING_MODEL needs to be migrated
Rem
Rem######################################################################################################
 
ALTER SESSION SET CURRENT_SCHEMA = "ODM";

Rem  ODM_APPLY_RESULT
Rem  ----------------

ALTER TABLE ODM_APPLY_RESULT RENAME TO ODM_APPLY_RESULT_R1;

CREATE TABLE ODM_APPLY_RESULT
 (ID NUMBER(20) NOT NULL
 ,NAME VARCHAR2(64 CHAR) NOT NULL
 ,START_TIMESTAMP TIMESTAMP
 ,END_TIMESTAMP TIMESTAMP
 ,DATA_LOCATION VARCHAR2(61)
 ,MODEL_NAME VARCHAR2(64 CHAR)
 ,OUTPUT_TABLE_LOCATION VARCHAR2(61)
 );


INSERT INTO ODM_APPLY_RESULT (
   ID,
   NAME,
   START_TIMESTAMP,
   END_TIMESTAMP,
   DATA_LOCATION,
   MODEL_NAME,
   OUTPUT_TABLE_LOCATION)
SELECT 
   ID,
   NAME,
   STARTING_TIMESTAMP,
   COMPLETION_TIMESTAMP,
   DATA_LOCATION,
   MODEL_NAME,
   OUTPUT_TABLE_LOCATION
FROM ODM_APPLY_RESULT_R1;

ALTER TABLE ODM_APPLY_RESULT
 ADD (CONSTRAINT APPLY_RESULT_R2_PK PRIMARY KEY
  (ID)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

ALTER TABLE ODM_APPLY_RESULT
 ADD (CONSTRAINT ODM_APPLY_RESULT_R2_UK UNIQUE
  (NAME)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_APPLY_RESULT_R1 CASCADE CONSTRAINTS;

Rem  ODM_CONFIGURATION
Rem  -----------------

ALTER TABLE ODM_CONFIGURATION RENAME TO ODM_CONFIGURATION_R1;

CREATE TABLE ODM_CONFIGURATION
 (DATA_TYPE VARCHAR2(32) NOT NULL
 ,NAME VARCHAR2(128) NOT NULL
 ,VALUE VARCHAR2(128)
 ,DESCRIPTION VARCHAR2(256)
 );

INSERT INTO ODM_CONFIGURATION(
   DATA_TYPE,
   NAME,
   VALUE,
   DESCRIPTION)
SELECT
   DATA_TYPE,
   NAME,
   VALUE,
   DESCRIPTION
FROM ODM_CONFIGURATION_R1;

ALTER TABLE ODM_CONFIGURATION
 ADD (CONSTRAINT ODM_CONFIG_R2_PK PRIMARY KEY
  (NAME)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_CONFIGURATION_R1 CASCADE CONSTRAINTS;


Rem  ODM_ERROR_TABLE
Rem  -----------------


ALTER TABLE ODM_ERROR_TABLE RENAME TO ODM_ERROR_TABLE_R1;

CREATE TABLE ODM_ERROR_TABLE
 (LANGUAGE VARCHAR2(3)
 ,ERROR_NUMBER NUMBER(6)
 ,ERROR_STRING VARCHAR2(1000 CHAR)
 );

INSERT INTO ODM_ERROR_TABLE(
  LANGUAGE,
  ERROR_NUMBER,
  ERROR_STRING)
SELECT
  LANGUAGE,
  ERROR_NUMBER,
  ERROR_STRING
FROM ODM_ERROR_TABLE_R1;

DROP TABLE ODM_ERROR_TABLE_R1 CASCADE CONSTRAINTS;


Rem  ODM_TEST_RESULT
Rem  ---------------

ALTER TABLE ODM_TEST_RESULT RENAME TO ODM_TEST_RESULT_R1;

CREATE TABLE ODM_TEST_RESULT
 (ID NUMBER(20) NOT NULL
 ,NAME VARCHAR2(64 CHAR) NOT NULL
 ,START_TIMESTAMP TIMESTAMP
 ,END_TIMESTAMP TIMESTAMP
 ,DATA_LOCATION VARCHAR2(61)
 ,MODEL_NAME VARCHAR2(64 CHAR)
 );

INSERT INTO ODM_TEST_RESULT(
 ID,
 NAME,
 START_TIMESTAMP,
 END_TIMESTAMP,
 DATA_LOCATION,
 MODEL_NAME)
SELECT
 ID,
 NAME,
 STARTING_TIMESTAMP,
 COMPLETION_TIMESTAMP,
 DATA_LOCATION,
 MODEL_NAME
FROM ODM_TEST_RESULT_R1;

COMMENT ON TABLE ODM_TEST_RESULT IS 'Common table to the three result tables: classification, regression, and lift. This will be populated as a result of invoking test() and computeLift() from the server side.'
/

COMMENT ON COLUMN ODM_TEST_RESULT.ID IS 'Sequence ID generated for the test result'
/

COMMENT ON COLUMN ODM_TEST_RESULT.NAME IS 'User provided name of the test result'
/

COMMENT ON COLUMN ODM_TEST_RESULT.DATA_LOCATION IS 'String version og location object without user name and password'
/

COMMENT ON COLUMN ODM_TEST_RESULT.MODEL_NAME IS 'String version of location object without user name and password'
/

PROMPT Creating Primary Key on 'ODM_TEST_RESULT'
ALTER TABLE ODM_TEST_RESULT
 ADD (CONSTRAINT TEST_RESULT_R2_PK PRIMARY KEY
  (ID)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/


PROMPT Creating Unique Key on 'ODM_TEST_RESULT'
ALTER TABLE ODM_TEST_RESULT
 ADD (CONSTRAINT ODM_TEST_RESULT_R2_UK UNIQUE
   (NAME)
  USING INDEX
  INITRANS 2
  MAXTRANS 255
  PCTFREE 10
  STORAGE
  (
    INITIAL 65536
    MINEXTENTS 1
    MAXEXTENTS UNLIMITED
  ))
/


DROP TABLE ODM_TEST_RESULT_R1 CASCADE CONSTRAINTS;

Rem  ODM_CATEGORY_MATRIX_ENTRY
Rem  ------------------------

ALTER TABLE ODM_CATEGORY_MATRIX_ENTRY RENAME TO ODM_CATEGORY_MATRIX_ENTRY_R1;

CREATE TABLE ODM_CATEGORY_MATRIX_ENTRY
 (ROW_CATEGORY VARCHAR2(64 CHAR) NOT NULL
 ,COLUMN_CATEGORY VARCHAR2(64 CHAR) NOT NULL
 ,VALUE NUMBER
 ,CATEGORY_MATRIX_ID NUMBER NOT NULL
 );

INSERT INTO ODM_CATEGORY_MATRIX_ENTRY(
 ROW_CATEGORY,
 COLUMN_CATEGORY,
 VALUE,
 CATEGORY_MATRIX_ID)
SELECT
 ROW_CATEGORY,
 COLUMN_CATEGORY,
 VALUE,
 CATEGORY_MATRIX_ID
FROM ODM_CATEGORY_MATRIX_ENTRY_R1;

COMMENT ON TABLE ODM_CATEGORY_MATRIX_ENTRY IS 'Populated as a result of invoking test() for a given classification function settings. Occurs at the server and stores the confusion matrices.'
/

COMMENT ON COLUMN ODM_CATEGORY_MATRIX_ENTRY.ROW_CATEGORY IS 'Category used as row index to this value'
/

COMMENT ON COLUMN ODM_CATEGORY_MATRIX_ENTRY.COLUMN_CATEGORY IS 'Category used as column index to this value'
/

COMMENT ON COLUMN ODM_CATEGORY_MATRIX_ENTRY.VALUE IS 'The value associated with this particular entry (row, column)'
/

ALTER TABLE ODM_CATEGORY_MATRIX_ENTRY
 ADD (CONSTRAINT CATEGORY_MATRIX_ENTRY_R2_PK PRIMARY KEY
  (CATEGORY_MATRIX_ID
  ,ROW_CATEGORY
  ,COLUMN_CATEGORY)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

ALTER TABLE ODM_CATEGORY_MATRIX_ENTRY ADD (CONSTRAINT
 ENTRY_2_MATRIX_R2_FK FOREIGN KEY
  (CATEGORY_MATRIX_ID) REFERENCES ODM_CLASSIFICATION_TEST_RESULT
  (TEST_RESULT_ID))
/



ALTER TABLE ODM_CATEGORY_MATRIX_ENTRY_R1 DISABLE CONSTRAINT ENTRY_2_MATRIX_FK;

DROP TABLE ODM_CATEGORY_MATRIX_ENTRY_R1 CASCADE CONSTRAINTS;


Rem  ODM_LIFT_RESULT
Rem  ---------------

ALTER TABLE ODM_LIFT_RESULT RENAME TO ODM_LIFT_RESULT_R1;

CREATE TABLE ODM_LIFT_RESULT
 (ID NUMBER(20) NOT NULL
 ,NAME VARCHAR2(64 CHAR) NOT NULL
 ,START_TIMESTAMP TIMESTAMP
 ,END_TIMESTAMP TIMESTAMP
 ,DATA_LOCATION VARCHAR2(61)
 ,MODEL_NAME VARCHAR2(64 CHAR)
 );

INSERT INTO ODM_LIFT_RESULT(
 ID,
 NAME,
 START_TIMESTAMP,
 END_TIMESTAMP,
 DATA_LOCATION,
 MODEL_NAME)
SELECT
 ID,
 NAME,
 STARTING_TIMESTAMP,
 COMPLETION_TIMESTAMP,
 DATA_LOCATION,
 MODEL_NAME
FROM ODM_LIFT_RESULT_R1;

COMMENT ON TABLE ODM_LIFT_RESULT IS 'Populated as a result of invoking computeLift(). Occurs at the server.'
/

COMMENT ON COLUMN ODM_LIFT_RESULT.NAME IS 'User provided name of the lift result'
/

COMMENT ON COLUMN ODM_LIFT_RESULT.DATA_LOCATION IS 'String version of location object without user name and password.'
/

COMMENT ON COLUMN ODM_LIFT_RESULT.MODEL_NAME IS 'String version of location object without user name and password.'
/

ALTER TABLE ODM_LIFT_RESULT
 ADD (CONSTRAINT LIFT_RESULT_R2_PK PRIMARY KEY
  (ID)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

ALTER TABLE ODM_LIFT_RESULT
 ADD (CONSTRAINT ODM_LIFT_RESULT_R2_UK UNIQUE
  (NAME)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_LIFT_RESULT_R1 CASCADE CONSTRAINTS;


Rem  ODM_LIFT_RESULT_ENTRY
Rem  ---------------------

ALTER TABLE ODM_LIFT_RESULT_ENTRY RENAME TO ODM_LIFT_RESULT_ENTRY_R1;

CREATE TABLE ODM_LIFT_RESULT_ENTRY
 (PERCENTAGE_RECORDS_CUMULATIVE NUMBER
 ,LIFT_QUANTILE NUMBER
 ,LIFT_CUMULATIVE NUMBER
 ,TARGETS_CUMULATIVE NUMBER
 ,NON_TARGETS_CUMULATIVE NUMBER
 ,TARGET_DENSITY NUMBER
 ,TARGET_DENSITY_CUMULATIVE NUMBER
 ,LIFT_RESULT_ID NUMBER(20)
 );

INSERT INTO ODM_LIFT_RESULT_ENTRY(
 PERCENTAGE_RECORDS_CUMULATIVE,
 LIFT_QUANTILE,
 LIFT_CUMULATIVE,
 TARGETS_CUMULATIVE,
 NON_TARGETS_CUMULATIVE,
 TARGET_DENSITY,
 TARGET_DENSITY_CUMULATIVE,
 LIFT_RESULT_ID)
SELECT
 PERCENTAGE_RECORDS_CUMULATIVE,
 LIFT_QUANTILE,
 LIFT_CUMULATIVE,
 TARGETS_CUMULATIVE,
 NON_TARGETS_CUMULATIVE,
 TARGET_DENSITY,
 TARGET_DENSITY_CUMULATIVE,
 LIFT_RESULT_ID
FROM ODM_LIFT_RESULT_ENTRY_R1;

ALTER TABLE ODM_LIFT_RESULT_ENTRY ADD (CONSTRAINT
 LIFT_RESULT_ENTRY_R2_FK FOREIGN KEY
  (LIFT_RESULT_ID) REFERENCES ODM_LIFT_RESULT
  (ID))
/

ALTER TABLE ODM_LIFT_RESULT_ENTRY_R1 DISABLE CONSTRAINT LIFT_RESULT_ENTRY_FK;

DROP TABLE ODM_LIFT_RESULT_ENTRY_R1 CASCADE CONSTRAINTS;

Rem  ODM_MINING_MODEL
Rem  ----------------

ALTER TABLE ODM_MINING_MODEL RENAME TO ODM_MINING_MODEL_R1;

CREATE TABLE ODM_MINING_MODEL
 (NAME VARCHAR2(64 CHAR) NOT NULL
 ,USER_NAME VARCHAR2(30)
 ,START_TIMESTAMP TIMESTAMP
 ,END_TIMESTAMP TIMESTAMP
 ,FUNCTION_NAME VARCHAR2(64)
 ,ALGORITHM_NAME VARCHAR2(64)
 ,DATA_LOCATION VARCHAR2(61)
 ,SERIALIZED_OBJECT BLOB
 ,BIN_NUMERICAL_TABLE VARCHAR2(30)
 ,BIN_CATEGORICAL_TABLE VARCHAR2(30)
 ,TABLE_1 VARCHAR2(30)
 ,TABLE_2 VARCHAR2(30)
 ,TABLE_3 VARCHAR2(30)
 ,TABLE_4 VARCHAR2(30)
 ,TABLE_5 VARCHAR2(30)
 ,TABLE_6 VARCHAR2(30)
 ,TABLE_7 VARCHAR2(30)
 );

INSERT INTO ODM_MINING_MODEL(
 NAME,
 USER_NAME,
 START_TIMESTAMP,
 END_TIMESTAMP,
 FUNCTION_NAME,
 ALGORITHM_NAME,
 DATA_LOCATION,
 SERIALIZED_OBJECT,
 BIN_NUMERICAL_TABLE,
 BIN_CATEGORICAL_TABLE,
 TABLE_1,
 TABLE_2,
 TABLE_3,
 TABLE_4,
 TABLE_5,
 TABLE_6,
 TABLE_7)
SELECT
 NAME,
 USER_NAME,
 STARTING_TIMESTAMP,
 COMPLETION_TIMESTAMP,
 FUNCTION_NAME,
 ALGORITHM_NAME,
 DATA_LOCATION,
 SERIALIZED_OBJECT,
 '',
 '',
 TABLE_1,
 TABLE_2,
 TABLE_3,
 TABLE_4,
 '',
 '',
 ''
FROM ODM_MINING_MODEL_R1;

COMMENT ON TABLE ODM_MINING_MODEL IS 'Populated as a result of invoking build().  Occurs at the server. Accessed by the client to retrieve the model metadata for viewing at the client, and to score and test with appropriate data.'
/

COMMENT ON COLUMN ODM_MINING_MODEL.NAME IS 'User provided name of the model'
/

COMMENT ON COLUMN ODM_MINING_MODEL.SERIALIZED_OBJECT IS 'Serialized Java object for the entire model.'
/

COMMENT ON COLUMN ODM_MINING_MODEL.TABLE_1 IS 'Table related to this model'
/

COMMENT ON COLUMN ODM_MINING_MODEL.TABLE_2 IS 'Table related to this model'
/

COMMENT ON COLUMN ODM_MINING_MODEL.TABLE_3 IS 'Table related to this model'
/

COMMENT ON COLUMN ODM_MINING_MODEL.TABLE_4 IS 'Table related to this model'
/

ALTER TABLE ODM_MINING_MODEL
 ADD (CONSTRAINT MINING_MODEL_R2_PK PRIMARY KEY
  (NAME)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_MINING_MODEL_R1 CASCADE CONSTRAINTS;


Rem  ODM_MINING_FUNCTION_SETTINGS
Rem  ----------------------------

ALTER TABLE ODM_MINING_FUNCTION_SETTINGS RENAME TO ODM_MINING_FUNCTION_R1;

CREATE TABLE ODM_MINING_FUNCTION_SETTINGS
 (NAME VARCHAR2(64 CHAR) NOT NULL
 ,USER_NAME VARCHAR2(30)
 ,CREATION_TIMESTAMP TIMESTAMP DEFAULT SYSDATE
 ,FUNCTION_NAME VARCHAR2(64)
 ,ALGORITHM_NAME VARCHAR2(64)
 ,SERIALIZED_OBJECT BLOB
 );

INSERT INTO ODM_MINING_FUNCTION_SETTINGS(
          NAME,
          USER_NAME,
          CREATION_TIMESTAMP,
          FUNCTION_NAME,
          ALGORITHM_NAME,
          SERIALIZED_OBJECT)
SELECT    NAME,
          USER_NAME,
          CREATION_TIMESTAMP,
          FUNCTION_NAME,
          ALGORITHM_NAME,
          SERIALIZED_OBJECT
FROM ODM_MINING_FUNCTION_R1;

COMMENT ON TABLE ODM_MINING_FUNCTION_SETTINGS IS 'Intended for Phase 2. Populated as a result of invoking store() from the client.'
/

COMMENT ON COLUMN ODM_MINING_FUNCTION_SETTINGS.NAME IS 'User provided name of the function settings'
/

COMMENT ON COLUMN ODM_MINING_FUNCTION_SETTINGS.SERIALIZED_OBJECT IS 'Serialized Java object for the entire function settings'
/

ALTER TABLE ODM_MINING_FUNCTION_SETTINGS
 ADD (CONSTRAINT MINING_FUNCTION_SETTINGS_R2_PK PRIMARY KEY
  (NAME)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_MINING_FUNCTION_R1 CASCADE CONSTRAINTS;


Rem  ODM_I_I_ANTECEDENT
Rem  ------------------

ALTER TABLE ODM_I_I_ANTECEDENT RENAME TO ODM_I_I_ANTECEDENT_R1;

CREATE TABLE ODM_I_I_ANTECEDENT
 (RULE_ID NUMBER(20)
 ,ATTRIBUTE_NAME VARCHAR2(30)
 ,VALUE NUMBER
 );

INSERT INTO ODM_I_I_ANTECEDENT(
 RULE_ID,
 ATTRIBUTE_NAME,
 VALUE)
SELECT
 RULE_ID,
 ATTRIBUTE_NAME,
 VALUE 
FROM ODM_I_I_ANTECEDENT_R1;

DROP TABLE ODM_I_I_ANTECEDENT_R1 CASCADE CONSTRAINTS;

Rem  ODM_I_I_RULE
Rem  ------------

ALTER TABLE ODM_I_I_RULE RENAME TO ODM_I_I_RULE_R1;

CREATE TABLE ODM_I_I_RULE
 (RULE_ID NUMBER(20) NOT NULL
 ,CONSEQUENT_ATTRIBUTE VARCHAR2(30)
 ,CONSEQUENT_VALUE NUMBER
 ,CONSEQUENT_SUPPORT NUMBER
 ,ANTECEDENT_SUPPORT NUMBER
 ,NUMBER_OF_ANTECEDENTS NUMBER(3)
 ,RULE_SUPPORT NUMBER
 ,RULE_CONFIDENCE NUMBER
 );

INSERT INTO ODM_I_I_RULE(
 RULE_ID,
 CONSEQUENT_ATTRIBUTE,
 CONSEQUENT_VALUE,
 CONSEQUENT_SUPPORT,
 ANTECEDENT_SUPPORT,
 NUMBER_OF_ANTECEDENTS,
 RULE_SUPPORT,
 RULE_CONFIDENCE)
SELECT
 RULE_ID, 
 CONSEQUENT_ATTRIBUTE,
 CONSEQUENT_VALUE,
 CONSEQUENT_SUPPORT,
 ANTECEDENT_SUPPORT,
 NUMBER_OF_ANTECEDENTS,
 RULE_SUPPORT,
 RULE_CONFIDENCE
FROM ODM_I_I_RULE_R1;

ALTER TABLE ODM_I_I_RULE
 ADD (CONSTRAINT I_I_RULE_R2_PK PRIMARY KEY
  (RULE_ID)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_I_I_RULE_R1 CASCADE CONSTRAINTS; 

Rem  ODM_MESSAGE_LOG
Rem  ---------------

ALTER TABLE ODM_MESSAGE_LOG RENAME TO ODM_MESSAGE_LOG_R1;

CREATE TABLE ODM_MESSAGE_LOG
 (ID NUMBER(20) NOT NULL
 ,MESSAGE_ID NUMBER(6)
 ,MESSAGE_TYPE VARCHAR2(32)
 ,MESSAGE_GROUP VARCHAR2(64)
 ,MESSAGE_LEVEL NUMBER(2,0)
 ,TIMESTAMP_ORIGINATING TIMESTAMP
 ,TIMESTAMP_NORMALIZED TIMESTAMP
 ,ORGANIZATION_ID VARCHAR2(16)
 ,COMPONENT_ID VARCHAR2(32)
 ,HOST_ID VARCHAR2(100)
 ,HOST_IP_ADDRESS VARCHAR2(32)
 ,MODULE_ID VARCHAR2(80)
 ,PROCESS_ID VARCHAR2(65)
 ,USER_ID VARCHAR2(80)
 ,UPSTREAM_COMPONENT VARCHAR2(32)
 ,DOWNSTREAM_COMPONENT VARCHAR2(32)
 ,EXECUTION_CONTEXT_ID NUMBER(20)
 ,ERROR_INSTANCE_ID NUMBER(20)
 ,MESSAGE_TEXT VARCHAR2(2000 CHAR)
 ,SUPPLEMENTAL_DETAILS VARCHAR2(2000 CHAR)
 ,ERROR_MESSAGE_STACK VARCHAR2(2000 CHAR)
 ,ERROR_MESSAGE_STACK2 VARCHAR2(2000 CHAR)
 );

INSERT INTO ODM_MESSAGE_LOG(
   ID,
   MESSAGE_ID,
   MESSAGE_TYPE,
   MESSAGE_GROUP,
   MESSAGE_LEVEL,
   TIMESTAMP_ORIGINATING,
   TIMESTAMP_NORMALIZED,
   ORGANIZATION_ID,
   COMPONENT_ID,
   HOST_ID,
   HOST_IP_ADDRESS,
   MODULE_ID,
   PROCESS_ID,
   USER_ID,
   UPSTREAM_COMPONENT,
   DOWNSTREAM_COMPONENT,
   EXECUTION_CONTEXT_ID,
   ERROR_INSTANCE_ID,
   MESSAGE_TEXT,
   SUPPLEMENTAL_DETAILS,
   ERROR_MESSAGE_STACK,
   ERROR_MESSAGE_STACK2)
SELECT
   ID,
   MESSAGE_ID,
   MESSAGE_TYPE,
   MESSAGE_GROUP,
   MESSAGE_LEVEL,
   TIMESTAMP_ORIGINATING,
   TIMESTAMP_NORMALIZED,
   ORGANIZATION_ID,
   COMPONENT_ID,
   HOST_ID,
   HOST_IP_ADDRESS,
   MODULE_ID,
   PROCESS_ID,
   USER_ID,
   UPSTREAM_COMPONENT,
   DOWNSTREAM_COMPONENT, 
   EXECUTION_CONTEXT_ID,
   ERROR_INSTANCE_ID,
   MESSAGE_TEXT,
   SUPPLEMENTAL_DETAILS,
   ERROR_MESSAGE_STACK,
   ERROR_MESSAGE_STACK2 
FROM ODM_MESSAGE_LOG_R1;

ALTER TABLE ODM_MESSAGE_LOG
 ADD (CONSTRAINT MESSAGE_LOG_R2_PK PRIMARY KEY
  (ID)
 USING INDEX
 INITRANS 2
 MAXTRANS 255
 PCTFREE 10
 STORAGE
 (
   INITIAL 65536
   MINEXTENTS 1
   MAXEXTENTS UNLIMITED
 ))
/

DROP TABLE ODM_MESSAGE_LOG_R1 CASCADE CONSTRAINTS;

Rem ODM_CLASSIFICATION_TEST_RESULT
Rem ------------------------------

ALTER TABLE ODM_CLASSIFICATION_TEST_RESULT DROP CONSTRAINT CLASS_TEST_RESULT_FK;

ALTER TABLE ODM_CLASSIFICATION_TEST_RESULT ADD CONSTRAINT CLASS_TEST_RESULT_FK FOREIGN KEY(TEST_RESULT_ID) REFERENCES ODM_TEST_RESULT(ID);
 
 
Rem  ODM_P_I_ITEM_RULES
Rem  ------------------

ALTER TABLE ODM_P_I_ITEM_RULES ADD(COUNT NUMBER);
 
Rem  ODM_ITEM_PRIOR
Rem  --------------

ALTER TABLE ODM_ITEM_PRIOR ADD(COUNT NUMBER);

DECLARE

 c_epsilon			CONSTANT VARCHAR2(20) := '(-13.8155105579)';

 v_rules_table_name		odm_model_util.TABLE_NAME_LIST_TYPE;
 v_priors_table_name		odm_model_util.TABLE_NAME_LIST_TYPE;

 v_sql_stmt			odm_model_util.SQL_STATEMENT_TYPE;

BEGIN

  COMMIT;

  v_sql_stmt :=
    'SELECT table_1 FROM odm_mining_model ' ||
    'WHERE algorithm_name = ''naiveBayes'' ';

  EXECUTE IMMEDIATE v_sql_stmt BULK COLLECT INTO v_rules_table_name;

  FOR i IN 1..v_rules_table_name.count LOOP

    v_sql_stmt :=
     'ALTER TABLE ' || v_rules_table_name(i) ||
     ' ADD (count NUMBER) ';

    EXECUTE IMMEDIATE v_sql_stmt;

    v_sql_stmt :=
      'UPDATE ' || v_rules_table_name(i) ||
      ' SET count = EXP(log_conditional_probability + ' || c_epsilon ||
                                       ') * EXP(log_consequent_count) ';

    EXECUTE IMMEDIATE v_sql_stmt;

  END LOOP;

  v_sql_stmt :=
    'SELECT table_2 FROM odm_mining_model ' ||
    'WHERE algorithm_name = ''naiveBayes'' ';

  EXECUTE IMMEDIATE v_sql_stmt BULK COLLECT INTO v_priors_table_name;

  FOR i IN 1..v_priors_table_name.count LOOP

    v_sql_stmt :=
     'ALTER TABLE ' || v_priors_table_name(i) ||
     ' ADD (count NUMBER) ';

    EXECUTE IMMEDIATE v_sql_stmt;

    v_sql_stmt :=
      'UPDATE ' || v_priors_table_name(i) ||
      ' SET count = EXP(log_prior) ';

    EXECUTE IMMEDIATE v_sql_stmt;

  END LOOP;

  COMMIT;

END;
/

Rem Assosiation Rule Models
Rem -----------------------

-- Sequence for generating unique table names
CREATE SEQUENCE odm_ar_seq;

-- Generate names of new tables
UPDATE odm_mining_model
   SET table_3 = 'IT_' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISS') || odm_ar_seq.nextval,
       table_4 = 'II_' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISS') || odm_ar_seq.nextval,
       table_5 = 'IS_' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISS') || odm_ar_seq.nextval,
       table_6 = 'RL_' || TO_CHAR(SYSTIMESTAMP,'YYMMDDHH24MISS') || odm_ar_seq.nextval
 WHERE algorithm_name = 'aPrioriAssociationRules';
COMMIT;

-- Clean up temporary sequence
DROP SEQUENCE odm_ar_seq; 

-- Create new tables
DECLARE 
  TYPE TABLE_NAME_LIST_TYPE IS TABLE OF VARCHAR2(30);
  
  v_old_rule_table_list     TABLE_NAME_LIST_TYPE;
  v_antecedent_table_list   TABLE_NAME_LIST_TYPE;
  v_item_table_list         TABLE_NAME_LIST_TYPE;
  v_iset_item_table_list    TABLE_NAME_LIST_TYPE;
  v_itemset_table_list      TABLE_NAME_LIST_TYPE;
  v_rule_table_list         TABLE_NAME_LIST_TYPE;
  
  v_sql_stmt                VARCHAR2(32767);
  i                         PLS_INTEGER;
  
  -- execute without exceptions
  PROCEDURE sure_exec (
    p_sql_stmt  VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE p_sql_stmt;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END sure_exec;
BEGIN 
  SELECT table_1, table_2, table_3, table_4, table_5, table_6 BULK COLLECT 
    INTO v_old_rule_table_list, v_antecedent_table_list, v_item_table_list,
         v_iset_item_table_list, v_itemset_table_list, v_rule_table_list
    FROM odm_mining_model
   WHERE algorithm_name = 'aPrioriAssociationRules';

  FOR i IN 1..v_old_rule_table_list.COUNT LOOP
    -- create ITEM table
    v_sql_stmt :=
      'CREATE TABLE %item_tab% (' ||
         'item_id         INTEGER, ' ||
         'attribute_name  VARCHAR2(30), ' ||
         'value           NUMBER, ' ||
         'display_name    VARCHAR2(96), ' ||
         'mapped_value    VARCHAR2(30), ' ||
         'weight          NUMBER)';
    v_sql_stmt := REPLACE(v_sql_stmt, '%item_tab%', v_item_table_list(i));
    sure_exec(v_sql_stmt);
    
    -- create ITEMSET_ITEM table
    v_sql_stmt :=
      'CREATE TABLE %iset_item_tab% (' ||
        'itemset_id       INTEGER, ' ||
        'item_id          INTEGER)';
    v_sql_stmt := REPLACE(v_sql_stmt, '%iset_item_tab%', v_iset_item_table_list(i));
    sure_exec(v_sql_stmt);

    -- create ITEMSET table
    v_sql_stmt :=
      'CREATE TABLE %iset_tab% (' ||
        'itemset_id       INTEGER, ' ||
        'support          NUMBER, ' ||
        'number_of_items  INTEGER)';
    v_sql_stmt := REPLACE(v_sql_stmt, '%iset_tab%', v_itemset_table_list(i));
    sure_exec(v_sql_stmt);
            
    -- create RULE table
    v_sql_stmt :=
      'CREATE TABLE %rule_tab% (' ||
        'rule_id               INTEGER, ' ||
        'antecedent_itemset_id INTEGER, ' ||
        'consequent_itemset_id INTEGER, ' ||
        'support               NUMBER, ' ||
        'confidence            NUMBER)';
    v_sql_stmt := REPLACE(v_sql_stmt, '%rule_tab%', v_rule_table_list(i));
    sure_exec(v_sql_stmt);
  END LOOP;
END;
/

-- Populate new tables
DECLARE 
  TYPE TABLE_NAME_LIST_TYPE IS TABLE OF VARCHAR2(30);
  
  v_old_rule_table_list     TABLE_NAME_LIST_TYPE;
  v_antecedent_table_list   TABLE_NAME_LIST_TYPE;
  v_item_table_list         TABLE_NAME_LIST_TYPE;
  v_iset_item_table_list    TABLE_NAME_LIST_TYPE;
  v_itemset_table_list      TABLE_NAME_LIST_TYPE;
  v_rule_table_list         TABLE_NAME_LIST_TYPE;
  
  v_rpiv_table_name         VARCHAR2(30);
  v_ipiv_table_name         VARCHAR2(30);
  
  v_sql_stmt                VARCHAR2(32767);
  v_sql_expr                VARCHAR2(32767);
  v_ant_num                 PLS_INTEGER;
  i                         PLS_INTEGER;
  k                         PLS_INTEGER;
  
  -- execute without exceptions
  PROCEDURE sure_exec (
    p_sql_stmt  VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE p_sql_stmt;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END sure_exec;
BEGIN 
  SELECT table_1, table_2, table_3, table_4, table_5, table_6 BULK COLLECT 
    INTO v_old_rule_table_list, v_antecedent_table_list, v_item_table_list,
         v_iset_item_table_list, v_itemset_table_list, v_rule_table_list
    FROM odm_mining_model
   WHERE algorithm_name = 'aPrioriAssociationRules';

  FOR i IN 1..v_old_rule_table_list.COUNT LOOP
    -- temporary tables
    v_rpiv_table_name := 'R' || v_rule_table_list(i);
    v_ipiv_table_name := 'R' || v_itemset_table_list(i);
  
    -- Max number of antecedents
    v_sql_stmt :=
      'SELECT MAX(number_of_antecedents) ' ||
        'FROM %old_rule_tab%';
    v_sql_stmt := REPLACE(v_sql_stmt, '%old_rule_tab%', v_old_rule_table_list(i));
    BEGIN
      EXECUTE IMMEDIATE v_sql_stmt INTO v_ant_num;
    EXCEPTION
      WHEN OTHERS THEN
        v_ant_num := 1;
    END;
    
    -- populate ITEM table
    v_sql_stmt :=
      'INSERT INTO %item_tab% (' ||
        'item_id, attribute_name, value, display_name, mapped_value, weight) ' ||
      'SELECT rownum item_id, attribute_name, value, value display_name, NULL mapped_value, NULL weight ' ||
        'FROM (SELECT attribute_name, value ' ||
                'FROM %old_rule_tab% ' ||
              'UNION ' || 
              'SELECT attribute_name, value ' ||
                'FROM %antc_tab%)';
    v_sql_stmt := REPLACE(v_sql_stmt, '%old_rule_tab%', v_old_rule_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%antc_tab%', v_antecedent_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%item_tab%', v_item_table_list(i));
    sure_exec(v_sql_stmt);
    COMMIT;
    
    -- pivoted rule table (RPIV)
    v_sql_stmt :=
      'CREATE TABLE %rpiv_tab% AS ' ||                                 
      'SELECT /*+ ORDERED USE_HASH(ri ap) */ ' ||
             'ri.rule_id, ap.a1, %ap_col%' ||
             'ri.c1, ri.noa, ri.sup, ri.conf, ri.asup, ri.csup ' ||
        'FROM (SELECT /*+ ORDERED USE_HASH(i r) */ ' ||
                     'r.rule_id, i.item_id c1, r.number_of_antecedents noa, r.support sup, ' || 
                     'r.confidence conf, r.antecedent_support asup, r.consequent_support csup ' ||
                'FROM %item_tab% i, %old_rule_tab% r ' ||
               'WHERE r.attribute_name = i.attribute_name ' ||
                 'AND r.value = i.value) ri, ' ||
             '(SELECT rule_id, ' ||
                     'MAX(CASE WHEN pos = 1 THEN item_id ELSE 0 END) a1' ||
                     '%pos_col% ' ||
                'FROM (SELECT /*+ ORDERED USE_HASH(i a) */ ' ||
                             'a.rule_id, i.item_id, ' ||
                             'ROW_NUMBER() OVER (PARTITION BY a.rule_id ORDER BY i.item_id ASC) pos ' ||
                        'FROM %item_tab% i, %antc_tab% a ' ||
                       'WHERE a.attribute_name = i.attribute_name ' ||
                         'AND a.value = i.value) ai ' ||
               'GROUP BY rule_id) ap ' ||
       'WHERE ri.rule_id = ap.rule_id';

    v_sql_expr := NULL;
    FOR k IN 2..v_ant_num LOOP
      v_sql_expr := v_sql_expr || 'ap.a' || k || ', '; 
    END LOOP;                 
    v_sql_stmt := REPLACE(v_sql_stmt, '%ap_col%', v_sql_expr);
    
    v_sql_expr := NULL;
    FOR k IN 2..v_ant_num LOOP
      v_sql_expr := v_sql_expr ||
        ', MAX(CASE WHEN pos = ' || k || ' THEN item_id ELSE 0 END) a' || k;
    END LOOP;
    v_sql_stmt := REPLACE(v_sql_stmt, '%pos_col%', v_sql_expr);

    v_sql_stmt := REPLACE(v_sql_stmt, '%old_rule_tab%', v_old_rule_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%antc_tab%', v_antecedent_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%item_tab%', v_item_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%rpiv_tab%', v_rpiv_table_name);
    sure_exec(v_sql_stmt);

    -- pivoted itemset table (IPIV)
    v_sql_stmt :=
      'CREATE TABLE %ipiv_tab% AS ' ||
      'SELECT rownum iid, iset.* ' ||
        'FROM (SELECT ra.a1 i1, %ap_col%' ||
                     'ra.noa, ra.asup sup ' ||
                'FROM %rpiv_tab% ra ' ||
              'UNION ' ||
              'SELECT rc.c1 i1 %null_col%, 1 noa, rc.csup sup ' ||
                'FROM %rpiv_tab% rc) iset';

    v_sql_expr := NULL;
    FOR k IN 2..v_ant_num LOOP
      v_sql_expr := v_sql_expr || 'ra.a' || k || ' i' || k || ', '; 
    END LOOP;                 
    v_sql_stmt := REPLACE(v_sql_stmt, '%ap_col%', v_sql_expr);
    
    v_sql_expr := NULL;
    FOR k IN 2..v_ant_num LOOP
      v_sql_expr := v_sql_expr || ', 0 i' || k;
    END LOOP;
    v_sql_stmt := REPLACE(v_sql_stmt, '%null_col%', v_sql_expr);

    v_sql_stmt := REPLACE(v_sql_stmt, '%ipiv_tab%', v_ipiv_table_name);
    v_sql_stmt := REPLACE(v_sql_stmt, '%rpiv_tab%', v_rpiv_table_name);
    sure_exec(v_sql_stmt);

    -- populate ITEMSET and ITEMSET_ITEM
    v_sql_stmt :=
      'INSERT ALL ' ||
      'WHEN i1 != 0 THEN ' ||
        'INTO %iset_item_tab% (itemset_id, item_id) ' ||
        'VALUES (iid, i1) ' ||
      '%item_cond%' ||
      'WHEN 1 = 1 THEN ' ||
        'INTO %iset_tab% (itemset_id, support, number_of_items) ' ||
        'VALUES (iid, sup, noa) ' ||
      'SELECT * ' ||
        'FROM %ipiv_tab%';

    v_sql_expr := NULL;
    FOR k IN 2..v_ant_num LOOP
      v_sql_expr := v_sql_expr ||
        'WHEN i' || k || ' != 0 THEN ' ||
          'INTO %iset_item_tab% (itemset_id, item_id) ' ||
          'VALUES (iid, i' || k || ') ';
    END LOOP;
    v_sql_stmt := REPLACE(v_sql_stmt, '%item_cond%', v_sql_expr);

    v_sql_stmt := REPLACE(v_sql_stmt, '%iset_item_tab%', v_iset_item_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%iset_tab%', v_itemset_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%ipiv_tab%', v_ipiv_table_name);
    sure_exec(v_sql_stmt);
    COMMIT;
    
    -- populate RULE table
    v_sql_stmt :=
      'INSERT INTO %rule_tab% (' ||
        'rule_id, antecedent_itemset_id, consequent_itemset_id, support, confidence) ' ||
      'SELECT rc.rule_id, rc.aid, ic.iid cid, rc.sup, rc.conf ' ||
        'FROM %ipiv_tab% ic, ' ||
             '(SELECT ra.rule_id, ia.iid aid, ra.c1, ra.sup, ra.conf ' ||
                'FROM %ipiv_tab% ia, %rpiv_tab% ra ' ||
               'WHERE ra.a1 = ia.i1' ||
                     '%join_col%) rc ' ||
       'WHERE rc.c1 = ic.i1 ' ||
         'AND ic.noa = 1';
         
    v_sql_expr := NULL;
    FOR k IN 2..v_ant_num LOOP
      v_sql_expr := v_sql_expr || ' AND ra.a' || k || ' = ia.i' || k;
    END LOOP;
    v_sql_stmt := REPLACE(v_sql_stmt, '%join_col%', v_sql_expr);

    v_sql_stmt := REPLACE(v_sql_stmt, '%rule_tab%', v_rule_table_list(i));
    v_sql_stmt := REPLACE(v_sql_stmt, '%ipiv_tab%', v_ipiv_table_name);
    v_sql_stmt := REPLACE(v_sql_stmt, '%rpiv_tab%', v_rpiv_table_name);
    sure_exec(v_sql_stmt);
    COMMIT;

    -- drop temporary itemset table
    v_sql_stmt := 
      'DROP TABLE ' || v_ipiv_table_name;
    sure_exec(v_sql_stmt);

    -- drop temporary rule table
    v_sql_stmt := 
      'DROP TABLE ' || v_rpiv_table_name;
    sure_exec(v_sql_stmt);

    -- drop OLD_RULE table
    v_sql_stmt := 
      'DROP TABLE ' || v_old_rule_table_list(i);
    sure_exec(v_sql_stmt);
    
    -- drop ANTECEDENT table
    v_sql_stmt := 
      'DROP TABLE ' || v_antecedent_table_list(i);
    sure_exec(v_sql_stmt);
  END LOOP;
END;
/
