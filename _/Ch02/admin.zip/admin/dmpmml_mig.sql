Rem
Rem $Header: dmpmmlnt_mig.sql 12-mar-2002.16:29:22 xbarr Exp $
Rem
Rem dmpmmlnt_mig.sql
Rem
Rem Copyright (c) 2002, Oracle Corporation.  All rights reserved.  
Rem
Rem    NAME
Rem      dmpmmlnt_mig.sql - Loading XML dataset via sqlldr 
Rem
Rem    DESCRIPTION
Rem      The script calls Unix shell script dmpmml.sh to load XML data into ODM account
Rem
Rem    NOTES
Rem      
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    xbarr       03/12/02 - xbarr_update_dbca_registry
Rem    xbarr       03/12/02 - modified to be used for Upgrade on NT
Rem    xbarr       03/07/02 - xbarr_tmini_update_translation
Rem    xbarr       02/26/02 - modified to include DBCA log directory input   
Rem    xbarr       01/14/02 - xbarr_modify_tmini_xsu12
Rem    xbarr       01/14/02 - Created
Rem


HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmpmml.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmpmml.dtd 
