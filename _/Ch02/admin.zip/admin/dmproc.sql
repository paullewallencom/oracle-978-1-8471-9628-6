Rem 
Rem $Header: dmproc.sql 27-mar-2002.15:10:36 xbarr Exp $
Rem
Rem dmproc.sql
Rem 
Rem Copyright (c) 2001, 2002, Oracle Corporation.  All rights reserved.  
Rem
Rem    NAME
Rem      dmproc.sql - Data Mining Procedures in various packages.
Rem
Rem    DESCRIPTION
Rem      This script installs the Data Mining internal packages for various
Rem      mining algorithms.
Rem
Rem    NOTES
Rem      This script should be run as ODMSYS. The routines provided in these
Rem      packages are also run as ODMSYS, since they are only called by the
Rem      ODM API presently, and not directly by the user.
Rem
Rem       MODIFIED (MM/DD/YY)
Rem       xbarr    03/27/02   - update Copyright 
Rem       xbarr    01/14/02   - use plb instead of sql 
Rem       dmukhin  10/16/01   - add dmnbah, dmnbab
Rem       mmcracke 10/12/01   - add dmkm
Rem       mmcampos 10/11/01   - eliminate dmclb, dmclh
Rem       mmcampos 10/08/01   - add dmcuh dmcub
Rem       bmilenov 10/08/01   - add dmoc package
Rem       dmukhin  09/21/01   - add dmsuperh, dmsuperb
Rem       pstengar 09/20/01   - Added call to dmmon.sql..
Rem       xbarr    09/18/01   - comment out dmnbctb/h due to errors
Rem       xbarr    09/18/01   - change plb to sql in dmproc
Rem       ramkrish 09/12/01   - uncomment dmnbctb/h due to errors
Rem       pkuntala 09/05/01   - Adding AI packages and model util packages.
Rem       xbarr    09/06/01   - add dmerr
Rem       dmukhin  09/05/01   - add mu and mt packages
Rem       ramkrish 09/04/01   - comment out dmnbctb
Rem       ramkrish 08/28/01   - Add external procedures
Rem       ramkrish 08/27/2001 - Creation for new env
Rem
Rem

Rem Load External Callout Defs
Rem @@dmnbcth
Rem @@dmnbctb

Rem Load ODM Specific packages
Rem --------------------------

Rem Error Package
@@dmerrh.plb
@@dmerrb.plb

Rem Model Util
@@dmmuh.plb
@@dmmub.plb

Rem Mining Transformations
@@dmmth.plb
@@dmmtb.plb

Rem Supervised Model
@@dmsuperh.plb
@@dmsuperb.plb

Rem Adaptive Bayesian Networks
@@dmabh.plb
@@dmabb.plb

Rem Association Rules
@@dmarh.plb
@@dmarb.plb

Rem Attribute Importance
@@dmaih.plb
@@dmaib.plb

Rem Clustering
@@dmcuh.plb
@@dmcub.plb
@@dmoch.plb
@@dmocb.plb
@@dmkmh.plb
@@dmkmb.plb

Rem Naive Bayes Apply
@@dmnbah.plb
@@dmnbab.plb

Rem Naive Bayes
@@dmnbh.plb
@@dmnbb.plb
  
Rem DMS Monitor
@@dmmon.plb
