Rem Copyright (c) 1991, 2002, Oracle Corporation.  All rights reserved.  
Rem    NAME
Rem      dminst.sql
Rem
Rem    DESCRIPTION
Rem      Run all sql scripts for the Data Mining option installation
Rem
Rem    RETURNS
Rem
Rem    NOTES
Rem     This script must be run while connected as SYS account
Rem
Rem     dmcrt.sql creates ODM & ODM_MTR schemas
Rem
Rem     catdm.sql calls all scripts which create ODM repository objects
Rem
Rem     &&1 - ODM tablespace
Rem     &&2 - ODM temporary tablespace
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem       xbarr    03/12/02 - execute dbms_registry in ODM 
Rem       xbarr    03/12/02 - add more in registry 
Rem       xbarr    03/08/02 - add registry information in dba_registry
Rem       xbarr    03/07/02 - use @?/dm/admin for accepting sqlldr logdir 
Rem       xbarr    02/26/02 - accept log directory for sqlldr using &&3 
Rem       xbarr    01/23/02 - reverse to use .sql for dmcrt 
Rem       xbarr    01/14/02 - use .plb for dmcrt 
Rem       xbarr    11/20/01 - Merged xbarr_update_installer
Rem
Rem    xbarr    10/31/01 - Creation
Rem
Rem    


@?/dm/admin/dmcrt.sql &&1 &&2 &&3

execute sys.dbms_registry.loading('ODM','Oracle Data Mining',NULL,'ODM');

@@catdm.sql

connect ODM/ODM;

execute sys.dbms_registry.loaded('ODM','9.2.0.1.0','Oracle Data Mining - Production');
