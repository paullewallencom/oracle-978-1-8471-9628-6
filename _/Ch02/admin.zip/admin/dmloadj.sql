Rem
Rem   Copyright (c) 2002 Oracle Corporation. All rights reserved.
Rem
Rem   Script to load odmapi.jar file into ODM schema
Rem
Rem   odmapi.jar is located under $ORACLE_HOME/dm/lib directory
Rem
set serveroutput on;

call dbms_java.set_output(10000);

call sys.dbms_java.loadjava('-force -verbose -resolve -synonym -grant PUBLIC dm/lib/odmapi.jar');


