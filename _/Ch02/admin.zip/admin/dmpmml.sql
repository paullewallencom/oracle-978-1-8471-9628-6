Rem
Rem $Header: dmpmmlnt.sql 26-feb-2002.16:36:02 kakchan Exp $
Rem
Rem dmpmmlnt.sql
Rem
Rem Copyright (c) 2002, Oracle Corporation.  All rights reserved.  
Rem
Rem    NAME
Rem      dmpmmlnt.sql - SQL script to load XML data   
Rem
Rem    DESCRIPTION
Rem      This script loads XML data for PMML module on NT platform
Rem
Rem    NOTES
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    kakchan     02/26/02 - replaced \ with .
Rem    xbarr       02/26/02 - removed extra log_file line 
Rem    kakchan     02/26/02 - .
Rem    kakchan     02/26/02 - added log file parameter
Rem    kakchan     02/14/02 - added data load script
Rem    xbarr       01/14/02 - xbarr_modify_tmini_xsu12
Rem    xbarr       01/14/02 - Created
Rem

DEFINE log_file_directory = &&3

Rem set NLS_LANG=.WE8ISO8859P1
HOST sqlldr ODM/ODM control=%ORACLE_HOME%/dm/admin/dmpmml.ctl data=%ORACLE_HOME%/dm/admin/dmpmml.dtd log=&log_file_directory.dmpmml.log
