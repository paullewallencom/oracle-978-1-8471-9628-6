Rem ##########################################################################
Rem
Rem Copyright (c) 2002, Oracle Corporation.  All rights reserved.  
Rem
Rem   Migration script to load Migration Java file odmapi.jar 
Rem   into ODM schema
Rem
Rem   The jar file is located under $ORACLE_HOME/dm/lib directory
Rem
Rem    04/25/02    xbarr,pkuntala  - change java drops to pl/sql block
Rem    02/11/02    xbarr   - add ODM prefix for droping 901 java classes (not use dropjava pack)
Rem    02/01/02    xbarr   - use dbms_java.dropjava to cleanup 901 Java Classes
Rem    01/24/02    xbarr   - add Java Stored Procedure call
Rem    01/23/02    xbarr   - add -schema in loadjava call
Rem    01/10/02    xbarr   - add Java cleanup
Rem    12/10/01    xbarr   - Creation
Rem
Rem ##########################################################################

ALTER SESSION SET CURRENT_SCHEMA = "SYS";

set serveroutput on;

execute dbms_java.grant_permission(UPPER('ODM'),'SYS:java.io.FilePermission','dm/lib/odmapi.jar','read');

ALTER SESSION SET CURRENT_SCHEMA = "ODM";

DECLARE
  dropall_cmd VARCHAR2(1000);
begin
  for drop_rec in
    (select dbms_java.longname(object_name) jname
      from dba_objects
      where owner = 'ODM')
  loop
     execute immediate
    'DROP JAVA CLASS "ODM' || '"."' || drop_rec.jname ||'"';
  end loop;
  commit;
  exception when others then
  null;
  end;
/


Rem   Load ODM 920 java classes

call dbms_java.set_output(10000);

call sys.dbms_java.loadjava('-schema ODM -force -verbose -resolve -synonym -grant PUBLIC dm/lib/odmapi.jar');

ALTER SESSION SET CURRENT_SCHEMA = "ODM";

Rem  Creating migration procedure
Rem 
create or replace package dmt_odm_migr authid current_user as 
procedure migrate
as language java
name 'oracle.dmt.migration920.ObjectMigrationTool.migrate()';
end dmt_odm_migr;
/

exec dmt_odm_migr.migrate;
