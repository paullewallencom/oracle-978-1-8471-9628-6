Rem ##########################################################################
Rem 
Rem Copyright (c) 1991, 2002, Oracle Corporation.  All rights reserved.  
Rem
Rem    NAME
Rem      dmmig.sql
Rem
Rem    DESCRIPTION
Rem	 Grant required privileges to ODM & ODM_MTR accounts 
Rem
Rem    RETURNS
Rem 
Rem    NOTES
Rem      This script must be run while connected as SYS   
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem       xbarr    04/26/02 - update ODM_MTR PW
Rem       xbarr    03/29/02 - add RESTRICTED SESSION to ODM_MTR 
Rem       xbarr    03/26/02 - add RESTRICTED SESSION to ODM due to upgrade mode 
Rem       xbarr    03/15/02 - add dbms_registry
Rem       xbarr    03/15/02 - update 901 ODM password 
Rem       xbarr    02/04/02 - add privs for RAC and performance 
Rem       xbarr    01/24/02 - xbarr_update_dmmtr_nt
Rem
Rem    xbarr    20/01/02 - Creation
Rem
Rem #########################################################################

Rem Grant Privileges for ODM
Rem ========================

grant
  CREATE DATABASE LINK,
  CREATE TRIGGER,
  CREATE PROCEDURE,
  CREATE SEQUENCE,
  CREATE SESSION,
  CREATE SYNONYM,
  CREATE VIEW,
  QUERY REWRITE,
  CREATE TABLE,
  ALTER SESSION,
  CREATE TYPE,
  SELECT_CATALOG_ROLE,
  AQ_ADMINISTRATOR_ROLE,
  AQ_USER_ROLE,
  ALTER SYSTEM,
  CREATE ANY TABLE,
  DROP ANY TABLE,
  CREATE ANY VIEW,
  DROP ANY VIEW,
  INSERT ANY TABLE,
  SELECT ANY TABLE,
  UPDATE ANY TABLE,
  CREATE ANY INDEX
to ODM;

grant select on dba_data_files to ODM;
grant select on dba_temp_files to ODM;
grant select on dba_jobs_running to ODM;
grant select on v_$session to ODM;
grant select on v_$parameter to ODM;


grant execute on dbms_sql to ODM;
grant execute on dbms_output to ODM;
grant execute on dbms_job to ODM;
grant execute on dbms_aqin to ODM;
grant execute on dbms_random to ODM;
grant execute on dbms_java to ODM;
grant execute on dbms_registry to ODM;
grant restricted session to ODM;

execute dbms_java.grant_permission(UPPER('ODM'),'SYS:java.net.SocketPermission','*','connect');

execute dbms_java.grant_permission(UPPER('ODM'),'SYS:java.io.FilePermission','dm/lib/odmapi.jar','read');

alter user ODM identified by ODM;

alter user ODM_MTR identified by MTRPW;

Rem  Grant required privileges to ODM_MTR
Rem =====================================

grant
  CREATE PROCEDURE,
  CREATE SEQUENCE,
  CREATE SESSION,
  CREATE SYNONYM,
  CREATE VIEW,
  CREATE TABLE,
  CREATE TYPE,
  SELECT_CATALOG_ROLE
to odm_mtr;

grant restricted session to ODM_MTR;
