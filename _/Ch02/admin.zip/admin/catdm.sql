rem 
rem $Header: catdm.sql 01-feb-2002.16:07:15 xbarr Exp $ 
rem 
Rem Copyright (c) 1991, 2002, Oracle Corporation.  All rights reserved.  
Rem    NAME
Rem      catdm.sql
Rem    DESCRIPTION
Rem	 Run all sql scripts for the Data Mining option
Rem    RETURNS
Rem 
Rem    NOTES
Rem      This script must be run while connected as ODM repository owner  
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    xbarr       02/01/02 - comment out dmupd.sql due to RAC change 
Rem    xbarr       01/23/02 - use .sql format for installation files 
Rem    xbarr       01/14/02 - add PMML data load
Rem    xbarr       01/14/02 - use .plb 
Rem    xbarr       11/20/01 - account info update
Rem    xbarr       11/03/01 - modified for ODM Installation
Rem    xbarr       10/22/01 - update dmupdate.sql
Rem    xbarr       10/17/01 - add dmupdate dmmtr dmerrtbl
Rem    xbarr       09/27/01 - add dmloadj.sql
Rem    xbarr       09/18/01 - change plb to sql extention
Rem    ramkrish    08/27/01 - Creation
Rem


connect ODM/ODM;

Rem DM Java objects
@@dmloadj.sql    

Rem DM Schemas
@@dmschema.plb
@@dmsupp.plb

Rem DM Error messages
@@dmutil.plb

Rem ODM API JSPs
@@dmapi.plb

Rem DM Procedures
@@dmproc.sql

Rem DM Configurations
Rem@@dmupd.sql

Rem DM Error Mesg load
@@dmerrtbl.sql

Rem DM PMML Data load
@@dmpmml.sql

connect ODM_MTR/MTRPW

Rem DM MTR Data load
@@dmmtr.sql
