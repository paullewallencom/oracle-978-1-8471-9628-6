Rem
Rem $Header: dmcleanup.sql 27-mar-2002.14:33:10 xbarr Exp $
Rem
Rem dmcleanup.sql
Rem
Rem Copyright (c) 2002, Oracle Corporation.  All rights reserved.
Rem

Rem
Rem NAME
Rem    DMCLEANUP.SQL
Rem
Rem FUNCTION
Rem    Cleans up the DM Repository temporary objects which are not longer needed

Rem
Rem    This script can be run when database experienced an unexpected crash
Rem
Rem NOTES
Rem   This needs to be run as ODM repository owner
Rem
Rem   MODIFIED    (MM/DD/YY)
Rem   xbarr        03/27/02 - update copyright 
Rem   xbarr        02/11/02 - xbarr_bug-2221210
Rem   xbarr        02/11/02 - Updated to exclude DMS_ & Clustering tables
Rem   xbarr        11/07/01 - Creation
Rem

SET TERMOUT OFF
set echo off
set head off
set pages 999
spool ./odm_cleanup.sql
select 'DROP TABLE ' || table_name || ';'
as dropall_cmd  from user_tables t where not exists
(select  UPPER(table_name) from
   (select table_1 table_name from odm_mining_model
     union
    select table_2 table_name from odm_mining_model
     union
    select table_3 table_name from odm_mining_model
     union
    select table_4 table_name from odm_mining_model
     union
    select table_5 table_name from odm_mining_model
     union
    select table_6 table_name from odm_mining_model
     union
    select table_7 table_name from odm_mining_model
   )a where a.table_name=t.table_name)
and table_name not like 'ODM_%' 
and table_name not like 'DMS_%'
and table_name not like 'CLUSTER%'
and table_name != 'CREATE$JAVA$LOB$TABLE'
and table_name != 'JAVA$CLASS$MD5$TABLE'
order by table_name asc;
--/
spool off
set echo on
set pages 24
set head on
spool ./odm_cleanup.log
@@./odm_cleanup.sql << exit
commit;
spool off
SET echo off
