Rem
Rem $Header: dmerrnt_mig.sql 19-mar-2002.14:52:53 xbarr Exp $
Rem
Rem dmerrnt_mig.sql
Rem
Rem Copyright (c) 2002, Oracle Corporation.  All rights reserved.  
Rem
Rem    NAME
Rem      dmerrnt_mig.sql - Loading ODM error table for ODM upgrade
Rem
Rem    DESCRIPTION
Rem        This script will load error messages into ODM_ERROR_TABLE via sqlldr
Rem
Rem    NOTES
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem       xbarr    03/19/02 - add commit 
Rem       xbarr    03/12/02 - xbarr_update_dbca_registry
Rem
Rem    03-12-02  xbarr modified for ODM upgrade to use
Rem    03-07-02  xbarr remove ^M
Rem    03-06-02  dwong Added control files
Rem    02-26-02  xbarr Modified to use log directory for sqlldr

ALTER SESSION SET CURRENT_SCHEMA = "ODM";

Rem  Cleanup 901 error table data

delete from odm_error_table;

commit;

Rem  Load 920 error table

HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_ptb_WE8MSWIN1252.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_ptb_WE8MSWIN1252.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_i_WE8MSWIN1252.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_i_WE8MSWIN1252.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_f_WE8MSWIN1252.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_f_WE8MSWIN1252.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_e_WE8MSWIN1252.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_e_WE8MSWIN1252.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_d_WE8MSWIN1252.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_d_WE8MSWIN1252.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_zht_ZHT16BIG5.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_zht_ZHT16BIG5.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_zhs_ZHS16GBK.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_zhs_ZHS16GBK.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_ko_KO16KSC5601.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_ko_KO16KSC5601.txt direct=yes 
HOST C:\oracle\product\9.2.0\db_1/bin/sqlldr userid=ODM/ODM control=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_ja_JA16SJIS.ctl data=C:\oracle\product\9.2.0\db_1/dm/admin/dmerrtbl_ja_JA16SJIS.txt direct=yes 
