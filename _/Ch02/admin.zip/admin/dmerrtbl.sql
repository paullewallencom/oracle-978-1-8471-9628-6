REM
REM  dmerrnt.sql
REM
REM  This script will load error messages into ODM_ERROR_TABLE via sqlldr on NT platform 
REM
Rem    MODIFY
Rem
Rem    03-07-02  xbarr remove extra ^M sign
Rem    03-06-02  dwong Added contol files
REM ---------------------------------------------------------------------
REM Load ODM error message
REM ---------------------------------------------------------------------

DEFINE log_file_directory = &&3

HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl.txt direct=yes log=&log_file_directory.dmerrtbl.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_ptb_WE8MSWIN1252.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_ptb_WE8MSWIN1252.txt direct=yes log=&log_file_directory.dmerrtbl_ptb_WE8MSWIN1252.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_i_WE8MSWIN1252.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_i_WE8MSWIN1252.txt direct=yes log=&log_file_directory.dmerrtbl_i_WE8MSWIN1252.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_f_WE8MSWIN1252.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_f_WE8MSWIN1252.txt direct=yes log=&log_file_directory.dmerrtbl_f_WE8MSWIN1252.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_e_WE8MSWIN1252.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_e_WE8MSWIN1252.txt direct=yes log=&log_file_directory.dmerrtbl_e_WE8MSWIN1252.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_d_WE8MSWIN1252.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_d_WE8MSWIN1252.txt direct=yes log=&log_file_directory.dmerrtbl_d_WE8MSWIN1252.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_zht_ZHT16BIG5.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_zht_ZHT16BIG5.txt direct=yes log=&log_file_directory.dmerrtbl_zht_ZHT16BIG5.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_zhs_ZHS16GBK.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_zhs_ZHS16GBK.txt direct=yes log=&log_file_directory.dmerrtbl_zhs_ZHS16GBK.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_ko_KO16KSC5601.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_ko_KO16KSC5601.txt direct=yes log=&log_file_directory.dmerrtbl_ko_KO16KSC5601.log
HOST sqlldr userid=ODM/ODM control=%ORACLE_HOME%/dm/admin/dmerrtbl_ja_JA16SJIS.ctl data=%ORACLE_HOME%/dm/admin/dmerrtbl_ja_JA16SJIS.txt direct=yes log=&log_file_directory.dmerrtbl_ja_JA16SJIS.log
